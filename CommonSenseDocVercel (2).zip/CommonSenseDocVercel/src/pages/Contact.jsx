import React from 'react';
export default function Contact() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Email: info.commonsense.com</p>
      <p>Phone: 425-584-8159</p>
    </div>
  );
}