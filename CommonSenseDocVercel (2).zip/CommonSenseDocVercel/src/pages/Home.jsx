import React from 'react';
export default function Home() {
  return (
    <div>
      <h1>Common Sense Document Services</h1>
      <p>Affordable Help for Everyday People</p>
    </div>
  );
}